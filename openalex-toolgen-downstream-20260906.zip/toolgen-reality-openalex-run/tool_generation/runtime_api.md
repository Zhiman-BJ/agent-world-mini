# Tool Runtime API

工具代码定义 `run(arguments, context)`，可以使用：

```python
context.environment
context.records.list(record_set_id, filters={}, limit=100, offset=0,
                     order_by=None, descending=False)
context.records.get(record_set_id, key)
context.records.create(record_set_id, record)
context.records.update(record_set_id, key, changes)
context.records.delete(record_set_id, key)
context.scope_root(scope_id)
```

`get` 的 key 必须包含该 Record Set 声明的全部 key_fields。`create` 接收完整记录；
`update` 和 `delete` 返回受影响记录数。`scope_root` 返回任务隔离副本中的 pathlib.Path。
只对 `access=copy_on_write` 的 Record Set 或 Scope 执行写操作。

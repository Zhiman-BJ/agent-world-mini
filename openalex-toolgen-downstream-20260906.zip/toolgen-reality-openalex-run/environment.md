# OpenAlex Publication Research Workspace

Offline research records and relationship tables derived from real OpenAlex snapshots.
